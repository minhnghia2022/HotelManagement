/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import entity.Room;
import entity.RoomType;

/**
 *
 * @author Minh Nghia
 */
public class RoomDB {

    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public RoomDB() {
        this.conn = DataBaseConnection.connectTODB();
    }

    public boolean InsertRoom(Room room) {
        try {
            st = conn.prepareStatement("INSERT INTO `room`(`RoomNo`, `bed_number`, `Tv`, `Wifi`, `air_conditioner`, `Minibar`, `room_class`) VALUES (?,?,?,?,?,?,?)");
            st.setString(1, room.getRoomNo());
            st.setString(2, room.getBed_number() + "");
            st.setString(3, room.isTv() + "");
            st.setString(4, room.isWifi() + "");
            st.setString(5, room.isAri_con() + "");
            st.setString(6, room.isMinibar() + "");
            st.setString(7, room.getRoom_class());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully inserted new Room");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        }
        return false;
    }

    public boolean UpdateRoom(Room room) {
        try {
            st = conn.prepareStatement("UPDATE `room` SET `bed_number`=?,`Tv`=?,`Wifi`=?,`air_conditioner`=?,`Minibar`=?,`room_class`=? WHERE `RoomNo`=?");
            st.setString(7, room.getRoomNo());
            st.setString(1, room.getBed_number() + "");
            st.setString(2, room.isTv() + "");
            st.setString(3, room.isWifi() + "");
            st.setString(4, room.isAri_con() + "");
            st.setString(5, room.isMinibar() + "");
            st.setString(6, room.getRoom_class());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Update Room");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update query Failed");
        }
        return false;
    }

    public void DeleteRoom(String RoomNo) {
        try {
            st = conn.prepareStatement("DELETE FROM `room` WHERE `RoomNo`=?");
            st.setString(1, RoomNo);
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Delete Room");
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ResultSet getAllRoom() {
        try {
            st = conn.prepareStatement("SELECT * FROM `room` ORDER BY bed_number ASC");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    public String boolToString(boolean value) {
        return value ? "true" : "false";
    }

    public boolean InsertRoomType(RoomType rt) {
        try {
            st = conn.prepareStatement("INSERT INTO `room_class`(`type`, `price`) VALUES (?,?)");
            st.setString(1, rt.getType());
            st.setInt(2, rt.getPrice());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully inserted new RoomType");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        }
        return false;

    }

    public boolean UpdateRoomType(RoomType rt) {
        try {
            st = conn.prepareStatement("UPDATE `room_class` SET `type`=?,`price`=? WHERE `ID`=?");
            st.setString(1, rt.getType());
            st.setInt(2, rt.getPrice());
            st.setInt(3, rt.getID());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Update RoomType");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update query Failed");
        }
        return false;
    }

    public void DeleteRoomType(String type) {
        try {
            st = conn.prepareStatement("DELETE FROM `room_class` WHERE `ID`=?");
            st.setString(1, type);
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Delete Room");
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ResultSet getAllRoomType() {
        try {
            st = conn.prepareStatement("SELECT * FROM `room_class` ORDER BY price DESC");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    public int getPrice(String type) {
        try {
            st = conn.prepareStatement("SELECT * FROM `room_class` WHERE type=?");
            st.setString(1, type);
            rs = st.executeQuery();
            while (rs.next()) {
                int price = rs.getInt("price");
                return price;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public boolean Insertlogbooking(String IDCustomer, String RoomNo, String TimeIn, String TimeOut, int price) {
        try {
            st = conn.prepareStatement("INSERT INTO `logbooking`(`IDCustomer`, `RoomNo`,`price` ,`TimecheckIn`, `TimeCheckOut`) VALUES (?,?,?,?,?)");
            st.setString(1, IDCustomer);
            st.setString(2, RoomNo);
            st.setInt(3, price);
            st.setString(4, TimeIn);
            st.setString(5, TimeOut);
            st.executeUpdate();
            UpdateStatusRoom(RoomNo);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void UpdateStatusRoom(String RoomNo) {
        try {
            st = conn.prepareStatement("UPDATE `room` SET `status`=? WHERE RoomNo = ?");
            st.setString(1, "busy");
            st.setString(2, RoomNo);
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean getStatusRoom(String RoomNo) {
        try {
            st = conn.prepareStatement("SELECT status FROM `room` WHERE RoomNo=?");
            st.setString(1, RoomNo);
            rs = st.executeQuery();
            if (rs.next()) {
                if (rs.getString("status").equals("busy")) {
                    return false;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    public ResultSet getRoomReady() {
        try {
            st = conn.prepareStatement("SELECT * FROM `room` WHERE status=?");
            st.setString(1, "Ready");
            rs = st.executeQuery();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public ResultSet getAllPaymentInfo(String RoomNo) {
        try {
            st = conn.prepareStatement("SELECT * FROM `orderitem` WHERE RoomNo=?");
            st.setString(1, RoomNo);
            rs = st.executeQuery();
            return rs;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning payment getAllPaymentInfo,bookingDB");
        }
        return null;
    }

    public ResultSet getAllCheckOut() {
        try {
            st = conn.prepareStatement("SELECT RoomNo,fullname,phone from logbooking "
                    + "join customer on logbooking.IDCustomer = customer.ID "
                    + "where has_checked_out = 0 ORDER BY logbooking.ID");
            rs = st.executeQuery();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public ResultSet getpriceCheckOut(String IDroom) {
        try {
            st = conn.prepareStatement("SELECT * FROM `logbooking` WHERE RoomNo=? AND has_checked_out = 0");
            st.setString(1, IDroom);
            rs = st.executeQuery();
            return rs;

        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }


}
