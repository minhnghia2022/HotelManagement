/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import entity.Customer;

/**
 *
 * @author Minh Nghia
 */
public class CustomerDB {

    Connection conn;
    PreparedStatement st = null;
    ResultSet rs = null;

    public CustomerDB() {
        this.conn = DataBaseConnection.connectTODB();
    }

    public boolean InsertCustomer(Customer customer) {
        try {
            st = conn.prepareStatement("INSERT INTO `customer`(`fullname`, `IDcard`, `Gender`, `Age`, `Phone`, `nationality`) VALUES (?,?,?,?,?,?)");
            st.setString(1, customer.getFullname());
            st.setString(2, String.valueOf(customer.getIDCard()));
            st.setString(3, customer.getGender());
            st.setString(4, String.valueOf(customer.getAge()));
            st.setString(5, customer.getPhone());
            st.setString(6, customer.getNationality());          
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully inserted new Customer");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        }
        return false;
    }

    public boolean UpdateCustomer(Customer customer) {
        try {
            st = conn.prepareStatement("UPDATE `customer` SET `fullname`=?,`IDcard`=?,`Gender`=?,`Age`=?,`Phone`=?,`nationality`=? WHERE `ID`=?");
            st.setString(7, String.valueOf(customer.getID()));
            st.setString(1, customer.getFullname());
            st.setString(2, String.valueOf(customer.getIDCard()));
            st.setString(3, customer.getGender());
            st.setString(4, String.valueOf(customer.getAge()));
            st.setString(5, customer.getPhone());
            st.setString(6, customer.getNationality());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully update Customer");
                return true;
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        }
        return false;
    }

    public void DeleteCustomer(String IDCustomer) {
        try {
            st = conn.prepareStatement("DELETE FROM `customer` WHERE ID=?");
            st.setString(1, IDCustomer);
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Deleted Customer");
            }
        } catch (SQLException ex) {
        }
    }

    public ResultSet getAllCustomer() {
        try {
            st = conn.prepareStatement("SELECT * FROM `customer` ORDER BY ID");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n error coming from returning all customer DB Operation");
        }
        return rs;
    }

}
