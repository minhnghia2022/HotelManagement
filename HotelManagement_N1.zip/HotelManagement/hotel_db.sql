-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th3 19, 2020 lúc 06:23 PM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `hotel_db`
--
CREATE DATABASE IF NOT EXISTS `hotel_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hotel_db`;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `account`
--

CREATE TABLE `account` (
  `ID` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `Employee_ID` varchar(11) NOT NULL,
  `role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `account`
--

INSERT INTO `account` (`ID`, `username`, `password`, `Employee_ID`, `role`) VALUES
(2, '123', '202cb962ac59075b964b07152d234b70', '123', 'Staff'),
(1, 'admin', '202cb962ac59075b964b07152d234b70', '1', 'admin'),
(3, 'lethi2020', '9cb9ce5a8454438075ea1255a401cbf2', 'A2', 'Manager');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bill`
--

CREATE TABLE `bill` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `Pricebill` int(50) NOT NULL DEFAULT 0,
  `Employee_ID` varchar(11) NOT NULL,
  `Time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `bill`
--

INSERT INTO `bill` (`ID`, `Name`, `RoomNo`, `Pricebill`, `Employee_ID`, `Time`) VALUES
(1, 'Minh Nghĩa', 'L2_P001', 55060000, 'A2', '1584316800000'),
(2, 'Bao Nhien 2', 'L4_P1', 0, 'A2', '1584316800000'),
(3, 'Minh Nghĩa', 'L1_P01', 76120000, '123', '1584316800000'),
(4, 'Minh Anh', 'L1_P02', 6220000, '123', '1584316800000'),
(5, 'Le Minh Thanh', 'L1_P01', 2800000, '123', '1584316800000'),
(6, 'Lê Thị Quỳnh Như', 'P03', 270000, 'A2', '1584506667085'),
(7, 'Trần Thị Hoàng Mai', 'P05', 6, '1', '1584585524218'),
(8, 'Trần Thị Minh Anh', 'P03', 260000, '1', '1584637277570');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

CREATE TABLE `customer` (
  `ID` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `IDcard` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(5) NOT NULL,
  `Phone` varchar(11) NOT NULL,
  `nationality` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`ID`, `fullname`, `IDcard`, `Gender`, `Age`, `Phone`, `nationality`) VALUES
(10, 'Sóc Trăng', '33333', 'Male', 33, '0222222222', 'VIETNAM'),
(9, 'Long An', '3333333', 'Male', 33, '0333333333', 'vn'),
(1, 'Minh Nghĩa', '366312090', 'Female', 20, '0399612992', 'VIETNAM'),
(2, 'Gia Khánh', '366312092', 'Male', 20, '0348400961', 'VIETNAM'),
(3, 'Trung Hưng', '366312093', 'Male', 12, '0348400961', 'VIETNAM'),
(7, 'Liem Phan', '366312995', 'Female', 20, '0348400965', 'VIETNAM'),
(8, 'Hà Nội', '366312996', 'Female', 22, '0348400952', 'VIETNAM'),
(11, 'Cao Bằng', '366312999', 'Female', 30, '0397674725', 'VIETNAM');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `employee`
--

CREATE TABLE `employee` (
  `ID` int(11) NOT NULL,
  `Employee_ID` varchar(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `Salary` int(52) NOT NULL DEFAULT 0,
  `Birthday` date NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `employee`
--

INSERT INTO `employee` (`ID`, `Employee_ID`, `fullname`, `position`, `Salary`, `Birthday`, `Gender`, `Note`) VALUES
(1, '1', 'Lê Minh Nghĩa', 'Sales Executive', 1000000, '2000-02-22', 'Male', 'Minh Nghia dz'),
(3, 'A1', 'Đặng Văn Hoàng', 'Receptionist', 1000000, '2005-12-01', 'Female', 'NHIÊN'),
(7, 'A2', 'Thầy Giáo Ba', 'Customer care', 10000000, '1998-08-20', 'Female', 'haiz'),
(5, 'A3', 'Cao Văn Ba', 'Receptionist', 123, '2000-02-20', 'Female', ''),
(2, 'A4', 'Nguyễn Cao Bằng', 'Receptionist', 10000000, '2000-03-20', 'Female', '<3');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gift`
--

CREATE TABLE `gift` (
  `ID` int(11) NOT NULL,
  `codegift` varchar(30) NOT NULL,
  `user` varchar(30) DEFAULT NULL,
  `value` int(11) NOT NULL,
  `endTime` varchar(50) NOT NULL,
  `used` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `gift`
--

INSERT INTO `gift` (`ID`, `codegift`, `user`, `value`, `endTime`, `used`) VALUES
(3, 'TEST-YS0ZEqs4', 'Trần Thị Minh Anh', 20000, '1584889374000', 1),
(4, 'TEST-YS0ZEqs4p0kL8u2j', NULL, 20000, '1584889374000', 1),
(5, 'TEST-YS0ZEqs4p0kL8u2j0vr3AvEz', NULL, 20000, '1584889374000', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `logbooking`
--

CREATE TABLE `logbooking` (
  `ID` int(11) NOT NULL,
  `IDCustomer` varchar(11) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `price` int(25) NOT NULL,
  `TimecheckIn` varchar(100) NOT NULL,
  `TimeCheckOut` varchar(100) NOT NULL,
  `has_checked_out` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `logbooking`
--

INSERT INTO `logbooking` (`ID`, `IDCustomer`, `RoomNo`, `price`, `TimecheckIn`, `TimeCheckOut`, `has_checked_out`) VALUES
(30, '10', 'P02', 1200000, '1584456793000', '1584456793000', 0),
(31, '8', 'P03', 120000, '1584333818000', '1584506618000', 1),
(32, '2', 'P04', 1200000, '1583804596000', '1584582196000', 0),
(33, '11', 'P05', 120000, '1584585489000', '1584585489000', 1),
(34, '11', 'P05', 120000, '1584585489000', '1584585489000', 0),
(35, '3', 'P01', 100000, '1584240512000', '1584586112000', 0),
(36, '7', 'P03', 120000, '1584413351000', '1584586151000', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orderitem`
--

CREATE TABLE `orderitem` (
  `ID` int(11) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `nameItem` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `orderitem`
--

INSERT INTO `orderitem` (`ID`, `RoomNo`, `nameItem`, `Price`, `Quantity`, `Total`) VALUES
(20, 'P02', 'Banh Mi', 20000, 2, 40000),
(21, 'P02', 'Banh Xeo', 20000, 1, 20000),
(23, 'P04', 'Banh Xeo', 20000, 2, 40000),
(24, 'P04', 'Pho', 50000, 1, 50000),
(25, 'P04', 'Coca', 10000, 1, 10000),
(26, 'P02', 'Banh Xeo', 20000, 1, 20000),
(27, 'P05', 'Coca', 10000, 2, 20000),
(28, 'P05', 'Banh Xeo', 20000, 2, 40000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `position`
--

CREATE TABLE `position` (
  `ID` int(11) NOT NULL,
  `position` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `position`
--

INSERT INTO `position` (`ID`, `position`) VALUES
(1, 'Receptionist'),
(2, 'Cashier'),
(3, 'Chef'),
(4, 'Bell man'),
(6, 'Customer care'),
(7, 'Sales Executive');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `room`
--

CREATE TABLE `room` (
  `ID` int(11) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `bed_number` int(11) NOT NULL,
  `Tv` varchar(10) NOT NULL DEFAULT '0',
  `Wifi` varchar(10) NOT NULL,
  `air_conditioner` varchar(10) NOT NULL,
  `Minibar` varchar(10) NOT NULL,
  `room_class` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Ready'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `room`
--

INSERT INTO `room` (`ID`, `RoomNo`, `bed_number`, `Tv`, `Wifi`, `air_conditioner`, `Minibar`, `room_class`, `status`) VALUES
(3, 'P01', 1, 'true', 'true', 'false', 'false', 'Standard', 'busy'),
(1, 'P02', 3, 'true', 'true', 'true', 'true', 'deluxe', 'busy'),
(2, 'P03', 2, 'true', 'true', 'true', 'true', 'VIP1', 'Ready'),
(4, 'P04', 1, 'true', 'true', 'false', 'false', 'deluxe', 'busy'),
(5, 'P05', 2, 'true', 'true', 'true', 'false', 'VIP1', 'busy'),
(6, 'P06', 2, 'true', 'false', 'true', 'false', 'VIP1', 'Ready');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `room_class`
--

CREATE TABLE `room_class` (
  `ID` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `price` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `room_class`
--

INSERT INTO `room_class` (`ID`, `type`, `price`) VALUES
(3, 'deluxe', '1200000'),
(1, 'Standard', '100000'),
(6, 'VIP 3', '250000'),
(4, 'VIP1', '120000'),
(5, 'VIP2', '150000');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `service`
--

CREATE TABLE `service` (
  `ID` int(11) NOT NULL,
  `IDService` varchar(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `service`
--

INSERT INTO `service` (`ID`, `IDService`, `name`, `price`) VALUES
(11, 'D1', 'Coca', 10000),
(12, 'D2', 'Sting', 10000),
(2, 'F1', 'Pho', 50000),
(4, 'F2', 'Banh Mi', 20000),
(10, 'F3', 'Banh Xeo', 20000);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `Employee_ID` (`Employee_ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`IDcard`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `gift`
--
ALTER TABLE `gift`
  ADD PRIMARY KEY (`codegift`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `logbooking`
--
ALTER TABLE `logbooking`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `orderitem`
--
ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`position`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`RoomNo`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `room_class`
--
ALTER TABLE `room_class`
  ADD PRIMARY KEY (`type`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`IDService`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `account`
--
ALTER TABLE `account`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `bill`
--
ALTER TABLE `bill`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `customer`
--
ALTER TABLE `customer`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `employee`
--
ALTER TABLE `employee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `gift`
--
ALTER TABLE `gift`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `logbooking`
--
ALTER TABLE `logbooking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT cho bảng `orderitem`
--
ALTER TABLE `orderitem`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT cho bảng `position`
--
ALTER TABLE `position`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `room`
--
ALTER TABLE `room`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `room_class`
--
ALTER TABLE `room_class`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `service`
--
ALTER TABLE `service`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
