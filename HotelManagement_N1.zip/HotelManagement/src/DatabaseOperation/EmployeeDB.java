/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import entity.Employee;
import entity.Position;

/**
 *
 * @author Minh Nghia
 */
public class EmployeeDB {

    Connection conn;
    PreparedStatement st = null;
    ResultSet rs = null;

    public EmployeeDB() {
        conn = DataBaseConnection.connectTODB();
    }

    public boolean insertEmployee(Employee employee) {
        try {

            st = conn.prepareStatement("INSERT INTO `employee`(`Employee_ID`, `fullname`, `position`, `Salary`, `Birthday`, `Gender`, `Note`) VALUES (?,?,?,?,?,?,?)");
            st.setString(1, employee.getEmployee_ID());
            st.setString(2, employee.getFullname());
            st.setString(3, employee.getPosition());
            st.setString(4, employee.getSalary() + "");
            st.setString(5, employee.getBirthday() + "");
            st.setString(6, employee.getGender());
            st.setString(7, employee.getNote());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully inserted new Employee");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        }
        return false;
    }

    public boolean UpdateEmployee(Employee emp) {
        try {
            st = conn.prepareStatement("UPDATE `employee` SET `fullname`=?,`position`=?,`Salary`=?,`Birthday`=?,`Gender`=?,`Note`=? WHERE Employee_ID=?");
            st.setString(7, emp.getEmployee_ID() + "");
            st.setString(1, emp.getFullname());
            st.setString(2, emp.getPosition());
            st.setString(3, emp.getSalary() + "");
            st.setString(4, emp.getBirthday() + "");
            st.setString(5, emp.getGender());
            st.setString(6, emp.getNote());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Update employee successful!!");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update query Failed");
        }
        return false;
    }

    public void DeleteEmployee(String Employee_ID) {
        try {
            st = conn.prepareStatement("DELETE FROM `employee` WHERE Employee_ID=?");
            st.setString(1, String.valueOf(Employee_ID));
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Deleted employee");
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ResultSet getAllEmployee() {
        try {
            String query = "SELECT * FROM `employee`";
            st = conn.prepareStatement(query);
            rs = st.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n");
        }

        return rs;
    }

    public boolean InsertPosition(Position p) {
        try {
            st = conn.prepareStatement("INSERT INTO `position`(`ID`, `position`) VALUES (?,?)");
            st.setString(1, p.getID() + "");
            st.setString(2, p.getNamePosition());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully inserted new Position");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "InsertQuery Failed");
        }
        return false;
    }

    public boolean UpdatePosition(Position p) {
        try {
            st = conn.prepareStatement("UPDATE `position` SET `position`=? WHERE `ID`=?");
            st.setString(1, p.getNamePosition());
            st.setString(2, p.getID() + "");
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Update Position");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Update query Failed");
        }
        return false;
    }

    public void DeletePosition(String ID) {
        try {
            st = conn.prepareStatement("DELETE FROM `position` WHERE `ID`=?");
            st.setString(1, ID);
            if(st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Delete Room");
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public ResultSet getAllPosition() {
        try {
            st = conn.prepareStatement("SELECT * FROM `position`");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

}
