/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import entity.Gift;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Minh Nghia
 */
public class GiftDB {

    Connection conn;
    PreparedStatement st = null;
    ResultSet rs = null;

    public GiftDB() {
        conn = DataBaseConnection.connectTODB();
    }

    public void InsertGift(Gift gt) {
        try {
            st = conn.prepareStatement("INSERT INTO `gift`(`codegift`, `value`, `endTime`) VALUES (?,?,?)");
            st.setString(1, gt.getCodeGift());
            st.setInt(2, gt.getValue());
            st.setString(3, String.valueOf(gt.getTime()) + "000");
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(GiftDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdateGift(String name, String code) {
        try {
            st = conn.prepareStatement("UPDATE `gift` SET `user`=?,`used`=? WHERE `codegift` = ?");
            st.setString(1, name);
            st.setInt(2, 1);
            st.setString(3, code);
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(GiftDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ResultSet getAllGift() {
        try {
            st = conn.prepareStatement("SELECT * FROM `gift` ORDER BY value DESC");
            rs = st.executeQuery();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(GiftDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public ResultSet getCodegift(String code) {
        try {
            st = conn.prepareStatement("SELECT `value`, `endTime`, `used` FROM `gift` WHERE codegift = ?");
            st.setString(1, code);
            System.out.println(st);
            rs = st.executeQuery();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(GiftDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void ScanGift() {
        long date = new Date().getTime();
        try {
            st = conn.prepareStatement("SELECT id,endTime FROM `gift`");
            rs = st.executeQuery();
            while (rs.next()) {
                if (Long.parseLong(rs.getString(2)) <= date) {
                    PreparedStatement sql = conn.prepareStatement("DELETE FROM gift WHERE ID=?");
                    sql.setString(1, rs.getString(1));
                    sql.executeUpdate();
                }
            }
            JOptionPane.showMessageDialog(null, "Scan Succesfull!!");

        } catch (SQLException ex) {
            Logger.getLogger(GiftDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
