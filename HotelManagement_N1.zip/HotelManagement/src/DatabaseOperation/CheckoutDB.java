/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Minh Nghia
 */
public class CheckoutDB {

    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public CheckoutDB() {
        this.conn = DataBaseConnection.connectTODB();
    }

    public void InsertBill(String Name, String RoomNo, String time, int Pricebill, String Employee_ID) {
        try {
            st = conn.prepareStatement("INSERT INTO `bill`(`Name`, `RoomNo`, `Pricebill`, `Employee_ID`, `Time`) VALUES (?,?,?,?,?)");
            st.setString(1, Name);
            st.setString(2, RoomNo);
            st.setInt(3, Pricebill);
            st.setString(4, Employee_ID);
            st.setString(5, time);
            if (st.executeUpdate() > 0) {
                updateRoom(RoomNo);
                updatelogbooking(RoomNo);
                DelteOrder(RoomNo);
                JOptionPane.showMessageDialog(null, "Payment succesfull!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateRoom(String RoomNo) {
        try {
            st = conn.prepareStatement("UPDATE `room` SET `status`=? WHERE `RoomNo`=?");
            st.setString(1, "Ready");
            st.setString(2, RoomNo);
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CheckoutDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updatelogbooking(String RoomNo) {
        try {
            st = conn.prepareStatement("UPDATE `logbooking` SET `has_checked_out`=? WHERE `RoomNo`=?");
            st.setInt(1, 1);
            st.setString(2, RoomNo);
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CheckoutDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DelteOrder(String RoomNo) {
        try {
            st = conn.prepareStatement("DELETE FROM `orderitem` WHERE `RoomNo`=?");
            st.setString(1, RoomNo);
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CheckoutDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
