/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExceptionHotel;

/**
 *
 * @author Minh Nghia
 */
public class Validate {

    public Validate() {
    }
    
    public boolean checkPhone(String phone){
     String regex1 = "^0+[0-9]{9}$";
     if(phone.matches(regex1)){
         return true;
     }
     return false;
    }
//    public static boolean checkIDCard(String IDCard){
//         String regex = "^[\\d]{9,12}";
//        String re
//    }
}
