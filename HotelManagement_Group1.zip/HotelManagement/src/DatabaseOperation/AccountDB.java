/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import entity.Account;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Minh Nghia
 */
public class AccountDB {

    Connection conn;
    PreparedStatement st = null;
    ResultSet rs = null;
    Account account = new Account();

    public AccountDB() {
        this.conn = DataBaseConnection.connectTODB();
    }

    public void InsertAccount(Account acc) {
        try {
            st = conn.prepareStatement("INSERT INTO `account`(`username`, `password`, `Employee_ID`, `role`) VALUES (?,?,?,?)");
            st.setString(1, acc.getUsername());
            st.setString(2, acc.getPasswrod());
            st.setString(3, acc.getEmployee_ID());
            st.setString(4, acc.getRole());
            st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Successfully Sign Up!!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Username exists!!, Please enter username other");
        }
    }

    public boolean LoginAcccount(String username, String password) {

        try {
            st = conn.prepareStatement("SELECT `username`, `password`,  `Employee_ID`, `role` FROM account where username=? and password=?");
            st.setString(1, username);
            st.setString(2, account.getMD5EncryptedValue(password));
            rs = st.executeQuery();
            if (rs.next()) {
                account.setUsername(rs.getString(1));
                account.setPasswrod(rs.getString(2));
                account.setEmployee_ID(rs.getString(3));
                account.setRole(rs.getString(4));
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password!", "Login message", 2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void updateAccount(String password, String username) {
        try {
            st = conn.prepareStatement("UPDATE `account` SET `password`=? WHERE `username`=?");
            st.setString(1, password);
            st.setString(2, username);
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Save change successful!!", "Update message", 2);
            } else {
                JOptionPane.showMessageDialog(null, "Save change Fail1!!!", "Update message", 2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DeleteAccount(String username) {
        try {
            st = conn.prepareStatement("DELETE FROM `account` WHERE `username`=?");
            st.setString(1, username);
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AccountDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ResultSet getAllAccount() {
        try {
            st = conn.prepareStatement("SELECT `ID`, `username`, `Employee_ID`, `role` FROM `account` ORDER BY ID ASC");
            rs = st.executeQuery();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(AccountDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Account getaccount() {
        return account;
    }
}
