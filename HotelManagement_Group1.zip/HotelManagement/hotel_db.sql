-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th3 27, 2020 lúc 02:06 PM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `hotel_db`
--
CREATE DATABASE IF NOT EXISTS `hotel_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hotel_db`;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `account`
--

CREATE TABLE `account` (
  `ID` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `Employee_ID` varchar(11) NOT NULL,
  `role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `account`
--

INSERT INTO `account` (`ID`, `username`, `password`, `Employee_ID`, `role`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin'),
(2, 'minhtoan2020', '3c16cc3d8d9e02d3828304f2cd6cd50f', 'HT02', 'Staff'),
(3, 'thiy2020', '25d55ad283aa400af464c76d713c07ad', 'HT03', 'Staff');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bill`
--

CREATE TABLE `bill` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `Pricebill` int(50) NOT NULL DEFAULT 0,
  `Employee_ID` varchar(11) NOT NULL,
  `Time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `bill`
--

INSERT INTO `bill` (`ID`, `Name`, `RoomNo`, `Pricebill`, `Employee_ID`, `Time`) VALUES
(1, 'Triệu Thế Quân', 'P06', 240000, 'admin', '1585312316149'),
(2, 'Lý Minh Khải', 'P04', 1200000, 'admin', '1585312321149'),
(3, 'Trần Thị Mai Thảo', 'P03', 230000, 'admin', '1585312333189'),
(4, 'Châu Thị Thanh Lương', 'P04', 3640000, 'admin', '1585313202936');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

CREATE TABLE `customer` (
  `ID` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `IDcard` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(5) NOT NULL,
  `Phone` varchar(11) NOT NULL,
  `nationality` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`ID`, `fullname`, `IDcard`, `Gender`, `Age`, `Phone`, `nationality`) VALUES
(35, 'Lý Thị Tuyết Dung', '126938585', 'Female', 37, '0364417298', 'VIETNAM'),
(69, 'Tạ Thị Mỹ Tiên', '135178197', 'Female', 52, '0901414285', 'VIETNAM'),
(24, 'Lâm Tuấn Dạ', '141716771', 'Male', 29, '0837353801', 'VIETNAM'),
(15, 'Thạch T.Bô Ri Qui', '145239415', 'Male', 44, '0329656809', 'VIETNAM'),
(71, 'Phùng Tiến Huy', '148948776', 'Male', 39, '0765832366', 'VIETNAM'),
(9, 'Đặng Gia Quí', '162419122', 'Male', 59, '0981052940', 'VIETNAM'),
(23, 'Sơn Thị Thanh Ma Ni', '163291166', 'Female', 65, '0925756021', 'VIETNAM'),
(61, 'Trần Thị Cẩm Lên', '174995736', 'Female', 36, '0376992442', 'VIETNAM'),
(28, 'Quách Thanh Đồng', '175487474', 'Male', 43, '0353861896', 'VIETNAM'),
(22, 'Thạch Thị Mỹ Dung', '189875889', 'Female', 28, '0345448620', 'VIETNAM'),
(67, 'Lư Yến Vân Anh', '193588337', 'Female', 44, '0359492482', 'VIETNAM'),
(29, 'Lý Trung Lý', '196718581', 'Male', 33, '0336958559', 'VIETNAM'),
(68, 'La Ngọc Lam', '214328647', 'Female', 50, '0394968660', 'VIETNAM'),
(14, 'Trần Thị Mai Thảo', '223473116', 'Female', 57, '0968828601', 'VIETNAM'),
(57, 'Trần Thị Tuyết Huệ', '227571786', 'Female', 64, '0788837354', 'VIETNAM'),
(21, 'Lâm Thị Huỳnh Nhi', '235143632', 'Female', 40, '0832574690', 'VIETNAM'),
(30, 'Trương Thị Ngọc Tiền', '257661329', 'Female', 55, '0332242158', 'VIETNAM'),
(47, 'Sơn Thị Si Nưa', '331568554', 'Female', 24, '0772628304', 'VIETNAM'),
(70, 'Nguyễn Hải Yến', '355495617', 'Female', 64, '0382806595', 'VIETNAM'),
(46, 'Lý Thị Xiềm Liều', '357649298', 'Female', 33, '0832328705', 'VIETNAM'),
(1, 'Lâm Minh Toàn', '363979613', 'Male', 51, '0795925500', 'VIETNAM'),
(20, 'Lý Thiên Phú', '374958459', 'Male', 46, '0813498353', 'VIETNAM'),
(54, 'Trần Thị Như Ý', '382971675', 'Female', 26, '0964573791', 'VIETNAM'),
(18, 'Thạch Thái', '383672593', 'Male', 55, '0334987319', 'VIETNAM'),
(48, 'Lý Thị Ngọc Như', '388438934', 'Female', 29, '0768836023', 'VIETNAM'),
(58, 'Trương Thị Bảo Trân', '415399645', 'Female', 48, '0365181324', 'VIETNAM'),
(51, 'Châu Trí Lâm', '447511447', 'Male', 36, '0911314365', 'VIETNAM'),
(41, 'Lý Đãng Cơ', '464231545', 'Male', 27, '0357036300', 'VIETNAM'),
(62, 'Dương Vĩnh Khương', '482476829', 'Male', 38, '0399623630', 'VIETNAM'),
(45, 'Võ Thị Bảo Trân', '484959452', 'Female', 47, '0868016267', 'VIETNAM'),
(4, 'Ong Thị Đoan Thục', '489136236', 'Female', 35, '0394892000', 'VIETNAM'),
(6, 'Huỳnh Như Nguyệt', '517618149', 'Female', 41, '0939405517', 'VIETNAM'),
(37, 'Ong Thị Diệu Ái', '523836943', 'Female', 59, '0362558201', 'VIETNAM'),
(63, 'Triệu Thế Quân', '527899368', 'Male', 32, '0382118121', 'VIETNAM'),
(34, 'Châu Siêng Hiệp', '531457662', 'Male', 22, '0327239010', 'VIETNAM'),
(19, 'Lâm Ka Đô', '557348764', 'Male', 60, '0988648623', 'VIETNAM'),
(64, 'Lê Vũ Huỳnh', '571958629', 'Male', 41, '0367011321', 'VIETNAM'),
(56, 'Quách Trí An', '572764183', 'Male', 33, '0364358374', 'VIETNAM'),
(49, 'Lâm Thị Huệ Nhi', '587924647', 'Female', 33, '0397655884', 'VIETNAM'),
(26, 'Trần Đăng Khoa', '593862422', 'Male', 35, '0767901143', 'VIETNAM'),
(77, 'Trần Phếm', '594675957', 'Female', 23, '0972769541', 'VIETNAM'),
(13, 'Trần Thị Su', '599185878', 'Female', 55, '0523085715', 'VIETNAM'),
(16, 'Quách Tuấn An', '622538353', 'Male', 25, '0337827419', 'VIETNAM'),
(53, 'Thạch Thị Siêu Y', '627322579', 'Female', 37, '0336409110', 'VIETNAM'),
(40, 'Lâm Hồng Phúc', '632425985', 'Male', 47, '0772129162', 'VIETNAM'),
(17, 'Trương Hoàng Thanh', '635826528', 'Male', 19, '0798032751', 'VIETNAM'),
(12, 'Nguyễn Thị Mỹ Duyên', '637221178', 'Female', 27, '0847035022', 'VIETNAM'),
(39, 'Lữ Minh Kha', '639676965', 'Male', 49, '0394955720', 'VIETNAM'),
(33, 'Ngô Thị Tú Ngân', '647751654', 'Female', 41, '0388502485', 'VIETNAM'),
(55, 'Dương Mỹ Xuyên', '659337488', 'Female', 62, '0888838067', 'VIETNAM'),
(75, 'Ong Hoàng Phi Long', '671618113', 'Male', 22, '0934162529', 'VIETNAM'),
(25, 'Hồ Văn Lịch', '674456518', 'Male', 21, '0389124314', 'VIETNAM'),
(76, 'Lâm Thị Tươi', '675221825', 'Female', 20, '0972769544', 'VIETNAM'),
(3, 'Châu Thị Thanh Lương', '711695533', 'Female', 23, '0339919530', 'VIETNAM'),
(36, 'Lý Ngọc Hoa', '715823363', 'Female', 29, '0962449336', 'VIETNAM'),
(42, 'Trần Thanh Phong Phú Quý', '725282795', 'Male', 55, '0763915801', 'VIETNAM'),
(60, 'Trương Thị Hải Yến', '754646657', 'Female', 50, '0355405697', 'VIETNAM'),
(10, 'Lê Thành Nhựt', '758157732', 'Male', 43, '0293888012', 'VIETNAM'),
(52, 'Lý Thái Nguyên', '773891793', 'Male', 29, '0917726641', 'VIETNAM'),
(31, 'Triệu Thị Ngọc Yến', '781529139', 'Female', 62, '0399811271', 'VIETNAM'),
(38, 'Lê Thị Ngọc Trâm', '785428271', 'Female', 19, '0915450564', 'VIETNAM'),
(73, 'Lâm Hán Nghĩ', '795128129', 'Male', 61, '0365937770', 'VIETNAM'),
(5, 'Ong Thị Mỷ Mỷ', '818539935', 'Female', 43, '0924099522', 'VIETNAM'),
(7, 'Dương Thị Y', '841418182', 'Female', 51, '0827504536', 'VIETNAM'),
(65, 'Lâm Thị Mỹ Tiên', '844889693', 'Female', 37, '0918928765', 'VIETNAM'),
(8, 'Sơn Thị Nhật Nam', '849811723', 'Female', 29, '0848067607', 'VIETNAM'),
(27, 'Quách Thị Huệ Cơ', '858545856', 'Female', 21, '0387901520', 'VIETNAM'),
(72, 'Lê Minh Luật', '865829961', 'Male', 49, '0333351787', 'VIETNAM'),
(11, 'Lý Minh Khải', '871719345', 'Male', 32, '0523085715', 'VIETNAM'),
(32, 'Ngô Thị Huệ', '873764453', 'Female', 18, '0857424311', 'VIETNAM'),
(2, 'Ngô Quốc Thái', '889493552', 'Male', 33, '0836169846', 'VIETNAM'),
(74, 'Thạch Minh Dũ', '911976231', 'Male', 24, '0971957260', 'VIETNAM'),
(44, 'Nguyễn Thị Như Ý', '915298755', 'Female', 41, '0912855408', 'VIETNAM'),
(50, 'Trần Thị Xiếu Tiên', '931215454', 'Female', 39, '0374260909', 'VIETNAM'),
(66, 'Ong Thị Yến Nhi', '958434458', 'Female', 41, '0397997406', 'VIETNAM'),
(43, 'Ong Thị Thảo', '966551727', 'Female', 58, '0328762104', 'VIETNAM'),
(59, 'Trần Lũy Hoán', '987132119', 'Male', 27, '0766995744', 'VIETNAM');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `employee`
--

CREATE TABLE `employee` (
  `ID` int(11) NOT NULL,
  `Employee_ID` varchar(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `Salary` int(52) NOT NULL DEFAULT 0,
  `Birthday` date NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `employee`
--

INSERT INTO `employee` (`ID`, `Employee_ID`, `fullname`, `position`, `Salary`, `Birthday`, `Gender`, `Note`) VALUES
(1, 'admin', 'Admin Kute', 'Admin', 0, '2000-02-22', 'Male', ''),
(7, 'HT01', 'Phạm Tuấn Khanh', 'Receptionist', 100000, '2000-01-02', 'Male', ''),
(2, 'HT02', 'Lâm Minh Toàn ', 'Customer care', 1000000, '2001-01-01', 'Male', ''),
(3, 'HT03', 'Dương Thị Y ', 'Customer care', 9000000, '2000-02-20', 'Female', ''),
(5, 'HT04', 'Đặng Gia Quí ', 'Bell man', 7000000, '1999-10-16', 'Male', ''),
(6, 'HT05', 'Trần Thị Su', 'Sales Executive', 11000000, '2001-05-05', 'Female', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gift`
--

CREATE TABLE `gift` (
  `ID` int(11) NOT NULL,
  `codegift` varchar(30) NOT NULL,
  `user` varchar(30) DEFAULT NULL,
  `value` int(11) NOT NULL,
  `endTime` varchar(50) NOT NULL,
  `used` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `logbooking`
--

CREATE TABLE `logbooking` (
  `ID` int(11) NOT NULL,
  `IDCustomer` varchar(11) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `price` int(25) NOT NULL,
  `TimecheckIn` varchar(100) NOT NULL,
  `TimeCheckOut` varchar(100) NOT NULL,
  `has_checked_out` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `logbooking`
--

INSERT INTO `logbooking` (`ID`, `IDCustomer`, `RoomNo`, `price`, `TimecheckIn`, `TimeCheckOut`, `has_checked_out`) VALUES
(1, '63', 'P06', 120000, '1585071368000', '1585244168000', 1),
(2, '11', 'P04', 1200000, '1585244396000', '1585244396000', 1),
(3, '14', 'P03', 120000, '1585157996000', '1585244396000', 1),
(4, '3', 'P04', 1200000, '1585053909000', '1585313109000', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orderitem`
--

CREATE TABLE `orderitem` (
  `ID` int(11) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `nameItem` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `orderitem`
--

INSERT INTO `orderitem` (`ID`, `RoomNo`, `nameItem`, `Price`, `Quantity`, `Total`) VALUES
(1, 'P02', 'Banh Mi', 20000, 2, 40000),
(2, 'P02', 'Banh Xeo', 20000, 1, 20000),
(3, 'P02', 'Banh Xeo', 20000, 1, 20000),
(4, 'P02', 'Banh Xeo', 20000, 9, 180000),
(5, 'P01', 'Banh Mi', 20000, 8, 160000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `position`
--

CREATE TABLE `position` (
  `ID` int(11) NOT NULL,
  `position` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `position`
--

INSERT INTO `position` (`ID`, `position`) VALUES
(1, 'Receptionist'),
(2, 'Cashier'),
(3, 'Chef'),
(4, 'Bell man'),
(6, 'Customer care'),
(7, 'Sales Executive');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `room`
--

CREATE TABLE `room` (
  `ID` int(11) NOT NULL,
  `RoomNo` varchar(11) NOT NULL,
  `bed_number` int(11) NOT NULL,
  `Tv` varchar(10) NOT NULL DEFAULT '0',
  `Wifi` varchar(10) NOT NULL,
  `air_conditioner` varchar(10) NOT NULL,
  `Minibar` varchar(10) NOT NULL,
  `room_class` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Ready'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `room`
--

INSERT INTO `room` (`ID`, `RoomNo`, `bed_number`, `Tv`, `Wifi`, `air_conditioner`, `Minibar`, `room_class`, `status`) VALUES
(1, 'P01', 3, 'true', 'true', 'false', 'false', 'deluxe', 'Ready'),
(2, 'P02', 3, 'true', 'true', 'false', 'false', 'Standard', 'Ready'),
(3, 'P03', 3, 'true', 'true', 'true', 'false', 'VIP1', 'Ready'),
(4, 'P04', 1, 'true', 'true', 'false', 'false', 'deluxe', 'Ready'),
(5, 'P05', 2, 'true', 'true', 'true', 'false', 'VIP1', 'Ready'),
(6, 'P06', 2, 'true', 'false', 'true', 'false', 'VIP1', 'Ready'),
(7, 'P07', 1, 'true', 'true', 'false', 'false', 'Standard', 'Ready'),
(8, 'P08', 2, 'true', 'true', 'true', 'true', 'deluxe', 'Ready'),
(9, 'P09', 3, 'true', 'true', 'true', 'false', 'deluxe', 'Ready'),
(10, 'P10', 3, 'true', 'true', 'true', 'true', 'deluxe', 'Ready');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `room_class`
--

CREATE TABLE `room_class` (
  `ID` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `price` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `room_class`
--

INSERT INTO `room_class` (`ID`, `type`, `price`) VALUES
(1, 'deluxe', 1200000),
(2, 'Standard', 100000),
(3, 'VIP1', 120000),
(4, 'VIP2', 150000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `service`
--

CREATE TABLE `service` (
  `ID` int(11) NOT NULL,
  `IDService` varchar(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `service`
--

INSERT INTO `service` (`ID`, `IDService`, `name`, `price`) VALUES
(1, 'D1', 'Coca', 10000),
(2, 'D2', 'Sting', 10000),
(3, 'F1', 'Pho', 50000),
(4, 'F2', 'Banh Mi', 20000),
(5, 'F3', 'Banh Xeo', 20000);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `Employee_ID` (`Employee_ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`IDcard`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `gift`
--
ALTER TABLE `gift`
  ADD PRIMARY KEY (`codegift`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `logbooking`
--
ALTER TABLE `logbooking`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `orderitem`
--
ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`ID`);

--
-- Chỉ mục cho bảng `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`position`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`RoomNo`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `room_class`
--
ALTER TABLE `room_class`
  ADD PRIMARY KEY (`type`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Chỉ mục cho bảng `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`IDService`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `account`
--
ALTER TABLE `account`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `bill`
--
ALTER TABLE `bill`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `customer`
--
ALTER TABLE `customer`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT cho bảng `employee`
--
ALTER TABLE `employee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `gift`
--
ALTER TABLE `gift`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `logbooking`
--
ALTER TABLE `logbooking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `orderitem`
--
ALTER TABLE `orderitem`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `position`
--
ALTER TABLE `position`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `room`
--
ALTER TABLE `room`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT cho bảng `room_class`
--
ALTER TABLE `room_class`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `service`
--
ALTER TABLE `service`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
